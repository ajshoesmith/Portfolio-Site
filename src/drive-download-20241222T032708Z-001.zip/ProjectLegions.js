import React from 'react';

function ProjectLegions() {
    return(
        <h1>Project Page 01</h1>
    );
}

export default ProjectLegions;