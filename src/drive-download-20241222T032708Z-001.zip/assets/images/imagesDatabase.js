import thumbMobileGame from './thumb-mobile-game.jpg';
import thumbFireRC from './Capture.PNG';
import thumbPortfolio from './thumbPortfolio.png';
import iconProgLang from './icon-programming_languages.png';
import iconWebDev from './icon-web_dev.png';
import iconManufacturing from './icon-manufacturing.png';
import iconDevTools from './icon-dev_tools.png';

export {thumbMobileGame, 
        thumbFireRC, 
        thumbPortfolio, 
        iconProgLang, 
        iconWebDev, 
        iconManufacturing, 
        iconDevTools};